<?php
$message = '<h2>ms2TreeHelper 1.0.8-pl</h2>'
    . '<p><strong>Author:</strong> Oleg Zakharov with OpenAi Generated ChatGPT.com</p>'
    . '<p><strong>Описание:</strong> добавляет маленькие кнопки-иконки массовой отметки категорий в toolbar дерева в окне создания/редактирования опции miniShop2.</p>'
    . '<ul><li>Добавить на все категории</li><li>Добавить ко всем дочерним категориям выделенного элемента</li><li>Снять со всех категорий</li></ul>'
    . '<p><strong>Совместимость:</strong> MODX Revolution 2.x / 3.x, miniShop2 3.x.</p>'
    . '<p><strong>Последнее обновление:</strong> 2026-03-24</p>'
    . '<p>Компонент не изменяет core MODX и core miniShop2. Подключение выполняется через плагин на событие <code>OnManagerPageBeforeRender</code>.</p>';
return $message;
