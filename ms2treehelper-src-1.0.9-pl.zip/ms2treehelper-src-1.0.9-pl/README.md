# ms2TreeHelper

Мини-пакет для MODX Revolution + miniShop2.

Добавляет bulk-кнопки над деревом категорий в окне создания/редактирования опции miniShop2.

## Что внутри
- `_build/` — сборка transport package
- `core/components/ms2treehelper/` — plugin + docs
- `assets/components/ms2treehelper/` — manager JS

## Быстрый старт
1. Положить папку `ms2treehelper-src` в корень сайта MODX.
2. Открыть `/ms2treehelper-src/_build/build.transport.php`.
3. Забрать zip из `core/packages/`.
4. Установить через `Extras -> Installer`.
