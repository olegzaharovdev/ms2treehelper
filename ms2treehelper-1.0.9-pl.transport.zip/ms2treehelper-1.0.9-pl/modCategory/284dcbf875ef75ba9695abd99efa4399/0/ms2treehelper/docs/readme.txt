--------------------
Extra: ms2TreeHelper
--------------------
Version: 1.0.9-pl
Since: March 24th, 2026
Author: Oleg Zakharov with OpenAi Generated ChatGPT.com
License: GNU GPLv2 (or later at your option)
Last updated: 2026-03-24

Описание
--------
ms2TreeHelper добавляет в окно создания/редактирования опции miniShop2
дополнительные кнопки массовой отметки категорий прямо в toolbar дерева.

Действия:
- Добавить на все категории
- Добавить ко всем дочерним категориям выделенного элемента
- Снять со всех категорий

Компонент не изменяет core MODX и core miniShop2.
Подключение выполняется через plugin на событие OnManagerPageBeforeRender.

Что входит в пакет
------------------
- Namespace: ms2treehelper
- Plugin: ms2TreeHelper
- Manager JS: assets/components/ms2treehelper/js/mgr/ms2treehelper.js
- PHP resolver: создаёт namespace и привязку plugin к событию OnManagerPageBeforeRender
- Документация: readme, changelog, license, setup-options

Совместимость
-------------
- MODX Revolution 2.x / 3.x
- miniShop2 3.0.x
- Менеджер MODX на ExtJS

Установка
---------
1. Скопируйте transport package в core/packages/
2. Установите пакет через Extras -> Installer
3. Откройте окно создания или редактирования опции miniShop2
4. В верхней панели дерева категорий появятся маленькие кнопки-иконки в стиле стандартного toolbar

Особенности
-----------
- Кнопки встроены в существующий toolbar дерева рядом с действиями
  "развернуть", "свернуть", "обновить".
- Скрипт ориентирован на реальные id окна miniShop2 вида:
  minishop2-window-option-create-option-categories
  minishop2-window-option-update-option-categories
- Для стабильности JS подключается во всём manager, но активируется
  только когда на странице найдено окно опции miniShop2.


Примечание по версии 1.0.9
-------------------------
- Иконки переведены на PNG-файлы в assets/components/ms2treehelper/img/ с прямыми URL на button background-image.
- Это устраняет конфликты с manager-темами и расширениями, которые перетирают CSS-классы и background shorthand.
