Ext.onReady(function () {
    var TEXT = {
        checkAll: 'Добавить на все категории',
        checkChildren: 'Добавить ко всем дочерним категориям',
        uncheckAll: 'Снять со всех категорий',
        noSelected: 'Сначала выделите элемент в дереве',
        title: 'ms2TreeHelper'
    };

    function getAssetsBaseUrl() {
        if (window.ms2TreeHelperAssetsUrl) {
            return window.ms2TreeHelperAssetsUrl;
        }

        var scripts = document.getElementsByTagName('script');
        for (var i = 0; i < scripts.length; i++) {
            var src = scripts[i].getAttribute('src') || '';
            if (src.indexOf('components/ms2treehelper/js/mgr/ms2treehelper.js') !== -1) {
                return src.replace(/js\/mgr\/ms2treehelper\.js(?:\?.*)?$/, '');
            }
        }

        return '/assets/components/ms2treehelper/';
    }

    var ASSETS = getAssetsBaseUrl();
    var ICONS = {
        checkAll: ASSETS + 'img/checkall.png',
        checkChildren: ASSETS + 'img/checkchildren.png',
        uncheckAll: ASSETS + 'img/uncheckall.png'
    };

    function ensureStyles() {
        if (document.getElementById('ms2treehelper-styles')) {
            return;
        }

        var css = ''
            + '.ms2treehelper-toolbar-fallback{margin:6px 0 8px 0;display:flex;gap:4px;flex-wrap:wrap;}';

        var style = document.createElement('style');
        style.type = 'text/css';
        style.id = 'ms2treehelper-styles';
        if (style.styleSheet) {
            style.styleSheet.cssText = css;
        } else {
            style.appendChild(document.createTextNode(css));
        }
        document.getElementsByTagName('head')[0].appendChild(style);
    }

    function eachNodeAsync(node, includeSelf, iterator, done) {
        if (!node) {
            if (done) done();
            return;
        }

        var process = function () {
            if (includeSelf) {
                iterator(node);
            }

            var children = node.childNodes || [];
            var index = 0;

            var next = function () {
                if (index >= children.length) {
                    if (done) done();
                    return;
                }

                eachNodeAsync(children[index], true, iterator, function () {
                    index++;
                    next();
                });
            };

            next();
        };

        var loaded = true;
        if (typeof node.isLoaded === 'function') {
            loaded = node.isLoaded();
        }

        if (node.leaf || loaded) {
            process();
        } else {
            node.expand(false, false, function () {
                process();
            });
        }
    }

    function setNodeChecked(tree, node, checked) {
        if (!node) {
            return;
        }

        node.attributes = node.attributes || {};
        node.attributes.checked = checked;

        var ui = (typeof node.getUI === 'function') ? node.getUI() : node.ui;
        if (ui && ui.checkbox) {
            ui.checkbox.checked = checked;
        }

        if (tree && tree.fireEvent) {
            tree.fireEvent('checkchange', node, checked);
        }
    }

    function getTreeCmp(panelEl) {
        if (!panelEl || !panelEl.id || typeof Ext === 'undefined' || !Ext.getCmp) {
            return null;
        }

        try {
            return Ext.getCmp(panelEl.id) || null;
        } catch (e) {
            return null;
        }
    }

    function getWindowEl(panelEl) {
        return panelEl ? panelEl.closest('.x-window') : null;
    }

    function getCategoriesInput(panelEl) {
        var win = getWindowEl(panelEl);
        if (!win) {
            return null;
        }

        return win.querySelector('input[name="categories"]');
    }

    function extractNumericId(nodeId) {
        if (!nodeId) {
            return null;
        }

        var match = String(nodeId).match(/(\d+)$/);
        return match ? parseInt(match[1], 10) : null;
    }

    function getNodeIdFromCheckbox(checkbox) {
        var li = checkbox ? checkbox.closest('li.x-tree-node') : null;
        if (!li) {
            return null;
        }

        var el = li.querySelector('.x-tree-node-el');
        if (!el) {
            return null;
        }

        return el.getAttribute('ext:tree-node-id') || el.getAttribute('data-node-id') || null;
    }

    function updateHiddenCategories(panelEl) {
        var input = getCategoriesInput(panelEl);
        if (!input) {
            return;
        }

        var ids = [];
        var seen = {};

        var checked = panelEl.querySelectorAll('input.x-tree-node-cb:checked');
        for (var i = 0; i < checked.length; i++) {
            var rawId = getNodeIdFromCheckbox(checked[i]);
            var numId = extractNumericId(rawId);
            if (numId !== null && !seen[numId]) {
                seen[numId] = true;
                ids.push(numId);
            }
        }

        input.value = Ext.util.JSON.encode(ids);
    }

    function rememberSelected(panelEl, target) {
        if (!panelEl || !target) {
            return;
        }

        var row = target.closest('.x-tree-node-el');
        if (!row) {
            return;
        }

        panelEl._ms2treehelperSelectedRow = row;
        var nodeId = row.getAttribute('ext:tree-node-id');
        if (nodeId) {
            panelEl._ms2treehelperSelectedNodeId = nodeId;
        }
    }

    function getSelectedDomRow(panelEl) {
        if (!panelEl) {
            return null;
        }

        if (panelEl._ms2treehelperSelectedRow) {
            return panelEl._ms2treehelperSelectedRow;
        }

        var selectedAnchor = panelEl.querySelector('.x-tree-selected');
        if (selectedAnchor) {
            return selectedAnchor.closest('.x-tree-node-el');
        }

        return null;
    }

    function getSelectedExtNode(panelEl) {
        var tree = getTreeCmp(panelEl);
        if (!tree) {
            return null;
        }

        try {
            var sm = tree.getSelectionModel ? tree.getSelectionModel() : null;
            if (sm && sm.getSelectedNode) {
                var selected = sm.getSelectedNode();
                if (selected) {
                    return selected;
                }
            }
        } catch (e) {}

        var nodeId = panelEl._ms2treehelperSelectedNodeId;
        if (nodeId && tree.getNodeById) {
            try {
                var byId = tree.getNodeById(nodeId);
                if (byId) {
                    return byId;
                }
            } catch (e2) {}
        }

        return null;
    }

    function toggleAllByDom(panelEl, checked) {
        var boxes = panelEl.querySelectorAll('input.x-tree-node-cb');
        for (var i = 0; i < boxes.length; i++) {
            boxes[i].checked = checked;
        }
        updateHiddenCategories(panelEl);
    }

    function toggleChildrenByDom(panelEl) {
        var row = getSelectedDomRow(panelEl);
        if (!row) {
            MODx.msg.alert(TEXT.title, TEXT.noSelected);
            return;
        }

        var li = row.closest('li.x-tree-node');
        if (!li) {
            MODx.msg.alert(TEXT.title, TEXT.noSelected);
            return;
        }

        var subtree = li.querySelector('ul.x-tree-node-ct');
        if (!subtree) {
            updateHiddenCategories(panelEl);
            return;
        }

        var boxes = subtree.querySelectorAll('input.x-tree-node-cb');
        for (var i = 0; i < boxes.length; i++) {
            boxes[i].checked = true;
        }

        updateHiddenCategories(panelEl);
    }

    function toggleAllByExt(panelEl, checked) {
        var tree = getTreeCmp(panelEl);
        if (!tree || !tree.getRootNode) {
            toggleAllByDom(panelEl, checked);
            return;
        }

        var root = tree.getRootNode();
        eachNodeAsync(root, false, function (node) {
            setNodeChecked(tree, node, checked);
        }, function () {
            updateHiddenCategories(panelEl);
        });
    }

    function toggleChildrenByExt(panelEl) {
        var tree = getTreeCmp(panelEl);
        var selected = getSelectedExtNode(panelEl);

        if (!tree || !selected) {
            toggleChildrenByDom(panelEl);
            return;
        }

        eachNodeAsync(selected, false, function (node) {
            setNodeChecked(tree, node, true);
        }, function () {
            updateHiddenCategories(panelEl);
        });
    }

    function bindPanelEvents(panelEl) {
        if (!panelEl || panelEl._ms2treehelperEventsBound) {
            return;
        }

        panelEl._ms2treehelperEventsBound = true;

        panelEl.addEventListener('click', function (e) {
            var t = e.target;
            if (!t) {
                return;
            }

            if (t.closest('.x-tree-node-el') || t.closest('.x-tree-node-anchor')) {
                rememberSelected(panelEl, t);
            }

            if (t.matches && t.matches('input.x-tree-node-cb')) {
                window.setTimeout(function () {
                    updateHiddenCategories(panelEl);
                }, 0);
            }
        });
    }

    function applyIconStyle(btn, tooltip, iconUrl) {
        if (!btn || !btn.getEl) {
            return;
        }

        var btnEl = btn.getEl();
        if (!btnEl || !btnEl.dom) {
            return;
        }

        btnEl.dom.setAttribute('title', tooltip);
        btnEl.dom.setAttribute('data-qtip', tooltip);

        var buttonEl = btnEl.child('button.x-btn-text');
        if (!buttonEl || !buttonEl.dom) {
            return;
        }

        var dom = buttonEl.dom;
        dom.setAttribute('title', tooltip);
        dom.innerHTML = '&nbsp;';
        dom.style.backgroundImage = 'url("' + iconUrl + '")';
        dom.style.backgroundRepeat = 'no-repeat';
        dom.style.backgroundPosition = 'center center';
        dom.style.backgroundSize = '18px 18px';
        dom.style.width = '18px';
        dom.style.height = '18px';
        dom.style.minWidth = '18px';
        dom.style.cursor = 'pointer';
    }


    function setTooltipHtml(tip, html) {
        if (!tip) {
            return;
        }

        if (tip.body && tip.body.update) {
            tip.body.update(html || '');
        } else if (tip.el) {
            var body = tip.el.child('.x-tip-body');
            if (body) {
                body.update(html || '');
            }
        } else {
            tip.html = html || '';
        }
    }

    function attachTooltip(btn, tooltip) {
        if (!btn || !btn.getEl || typeof Ext === 'undefined' || !Ext.ToolTip) {
            return;
        }

        var btnEl = btn.getEl();
        if (!btnEl) {
            return;
        }

        var buttonEl = btnEl.child('button.x-btn-text') || btnEl;

        try {
            if (Ext.QuickTips && Ext.QuickTips.init) {
                Ext.QuickTips.init();
            }
        } catch (e) {}

        if (buttonEl && buttonEl.dom) {
            buttonEl.dom.setAttribute('title', tooltip);
            buttonEl.dom.setAttribute('data-qtip', tooltip);
        }

        var tip = new Ext.ToolTip({
            target: buttonEl,
            html: tooltip,
            dismissDelay: 0,
            showDelay: 120,
            hideDelay: 0,
            autoHide: true,
            trackMouse: false,
            listeners: {
                beforeshow: function (t) {
                    setTooltipHtml(t, tooltip);
                    return true;
                },
                hide: function (t) {
                    setTooltipHtml(t, '');
                }
            }
        });

        btn._ms2treehelperTip = tip;
        if (btn.on) {
            btn.on('destroy', function () {
                if (btn._ms2treehelperTip && btn._ms2treehelperTip.destroy) {
                    btn._ms2treehelperTip.destroy();
                }
            });
        }
    }

    function addIconButton(rowEl, tooltip, iconUrl, handler) {
        var td = document.createElement('td');
        td.className = 'x-toolbar-cell';
        rowEl.appendChild(td);

        var host = document.createElement('span');
        td.appendChild(host);

        var btn = new Ext.Button({
            renderTo: host,
            cls: 'x-btn-icon',
            text: '&nbsp;',
            tooltip: tooltip,
            handler: handler
        });

        applyIconStyle(btn, tooltip, iconUrl);
        attachTooltip(btn, tooltip);
        return btn;
    }

    function renderButtons(panelEl) {
        if (!panelEl || panelEl._ms2treehelperButtonsRendered) {
            return;
        }

        ensureStyles();

        var tbar = panelEl.querySelector('.x-panel-tbar');
        var toolbarRow = tbar ? tbar.querySelector('.x-toolbar-left-row') : null;

        if (toolbarRow) {
            addIconButton(toolbarRow, TEXT.checkAll, ICONS.checkAll, function () {
                toggleAllByExt(panelEl, true);
            });

            addIconButton(toolbarRow, TEXT.checkChildren, ICONS.checkChildren, function () {
                toggleChildrenByExt(panelEl);
            });

            addIconButton(toolbarRow, TEXT.uncheckAll, ICONS.uncheckAll, function () {
                toggleAllByExt(panelEl, false);
            });
        } else {
            var body = panelEl.querySelector('.x-panel-body');
            if (!body) {
                return;
            }

            var host = document.createElement('div');
            host.className = 'ms2treehelper-toolbar-fallback';

            panelEl.insertBefore(host, panelEl.firstChild);

            new Ext.Button({
                renderTo: host,
                text: TEXT.checkAll,
                handler: function () {
                    toggleAllByExt(panelEl, true);
                }
            });

            new Ext.Button({
                renderTo: host,
                text: TEXT.checkChildren,
                handler: function () {
                    toggleChildrenByExt(panelEl);
                }
            });

            new Ext.Button({
                renderTo: host,
                text: TEXT.uncheckAll,
                handler: function () {
                    toggleAllByExt(panelEl, false);
                }
            });
        }

        panelEl._ms2treehelperButtonsRendered = true;
        bindPanelEvents(panelEl);
        updateHiddenCategories(panelEl);
    }

    function scan() {
        var panels = document.querySelectorAll('[id^="minishop2-window-option-"][id$="-option-categories"]');
        for (var i = 0; i < panels.length; i++) {
            renderButtons(panels[i]);
        }
    }

    scan();
    window.setInterval(scan, 1000);
});
